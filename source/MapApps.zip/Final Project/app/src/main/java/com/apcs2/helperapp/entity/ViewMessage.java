package com.apcs2.helperapp.entity;

import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class ViewMessage {
    TextView time;
    public View avatar;
    public TextView name;
    public TextView messageBody;

}
