package com.apcs2.helperapp.entity;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;


public class ViewHouse {

    TextView price;
    public ImageView houseImage;
    public TextView type;
    public TextView address;
}
