package com.apcs2.helperapp.entity;

import android.widget.LinearLayout;
import android.widget.TextView;

public class ViewMessage {
    TextView message;
    TextView username;
    TextView time;
    LinearLayout chatSegment;

}
